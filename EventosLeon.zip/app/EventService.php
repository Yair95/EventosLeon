<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventService extends Model
{
    protected $fillable = ['service_id', 'event_id'];
}
