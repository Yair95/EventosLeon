  <div class="form-group">
    <div class="form-group col-md-6">
      <label for="name">Nombre</label>
      <input type="text" class="form-control" name="name" id="name">
    </div>
    <div class="form-group col-md-6">
    <label for="email">Correo</label>
    <input type="email" class="form-control" aria-describedby="emailHelp" name="email" id="email">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="password">Contraseña</label>
      <input type="password" class="form-control" name="password" id="password">
    </div>
  </div>
