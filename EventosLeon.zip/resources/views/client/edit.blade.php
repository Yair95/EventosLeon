@include('data_contact.create')
<div class="form-group">
    <label for="exampleFormControlSelect1">Prestigio</label>
    <select class="form-control" id="prestige" name="prestige">
      <option></option>
      <option>0</option>
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
<div class="form-group">
	        		<label for="des">Comentarios</label>
	        		<textarea name="comments" id="comments" cols="20" rows="3" class="form-control"></textarea>
</div>
