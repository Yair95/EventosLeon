<a id_temporalyService="{{ $temporary_event_service_id }}" class="btn btn-danger btn-sm delete-service">
    <span class="fa fa-trash"></span>
</a>
