<div class="form-row">
    <div class="form-group col-md-6">
      <input type="text" class="form-control" placeholder="First name" name="name" id="name">
    </div>
    <div class="form-group col-md-6">
      <input type="text" class="form-control" placeholder="Last name" name="lastname" id="lastname">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="phone1">Teléfono 1</label>
      <input type="number" class="form-control" name="phone1" id="phone1">
    </div>
    <div class="form-group col-md-6">
      <label for="phone2">Teléfono 2</label>
      <input type="number" class="form-control" name="phone2" id="phone2">
    </div>
  </div>

  <div class="form-group">
    <div class="form-group col-md-12">
    <label for="email">Email</label>
    <input type="email" class="form-control" aria-describedby="emailHelp" name="email" id="email">
    </div>
  </div>
