<div class="form-group">
  <div class="form-group col-md-6">
    <label for="status">Estatus</label>
    <select class="form-control" name="status" id="status" required>
            <option value="0">Anticipado</option>
            <option value="1">Pendiente</option>
    </select>
  </div>
  <div class="form-group col-md-6">
    <label for="total">total</label>
    <input type="number" class="form-control" name="total" id="total" required>
  </div>
</div>
