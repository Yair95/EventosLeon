<button class="btn btn-primary btn-sm"
  data-id="{{$prepaid_id}}"
  data-total="{{$total}}"
  data-status="{{$status}}"
  data-toggle="modal" data-target="#edit"><i class="fa fa-edit"></i></button>
