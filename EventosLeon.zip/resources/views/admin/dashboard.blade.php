@extends('admin.layout')

@section('content')
  <h1>Bienvenido</h1>
  <h3>Sistema de administración de eventos D'Leon</h3>
@stop
