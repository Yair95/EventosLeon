<?php

use Faker\Generator as Faker;

$factory->define(App\data_contact::class, function (Faker $faker) {
    return [
        //
    ];
});
