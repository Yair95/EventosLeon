<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>Eventos<small>Agregar Evento</small></h1>
    </section>

    <form action="<?php echo e(route('event.eventservice')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php echo $__env->make('event.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="form-group col-md-6">
            <button type="submit" class="btn btn-primary">Continuar</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <?php echo $__env->make('event.partials.script_create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>