

<a href="<?php echo e(route('client.show', $id)); ?>" class="btn btn-info btn-sm">
  <i class="fa fa-eye"></i></a>

<button class="btn btn-primary btn-sm"
  data-idclient="<?php echo e($id); ?>"
  data-nameclient="<?php echo e($name); ?>"
  data-lastnameclient="<?php echo e($lastname); ?>"
  data-phone1client="<?php echo e($phone1); ?>"
  data-phone2client="<?php echo e($phone2); ?>"
  data-emailclient="<?php echo e($email); ?>"
  data-prestigeclient="<?php echo e($prestige); ?>"
  data-commentsclient="<?php echo e($comments); ?>"
  data-toggle="modal" data-target="#edit"><i class="fa fa-edit"></i></button>

<a class="btn btn-danger btn-sm" onclick="add( <?php echo e($data_contact_id); ?> );" data-id="<?php echo e($id); ?>">
  <i class="fa fa-trash"></i></a>


<!--
<a  id="delete" onclick="add( <?php echo e($id); ?> );" data-idclient="<?php echo e($id); ?>" class="btn btn-danger btn-sm">
  <i class="fa fa-trash"></i></a>


<a href="" class="button" data-id="<?php echo e($id); ?>">Delete</a>
href="<?php echo e(route('client.destroy', $id)); ?>"

  <button type="button" onclick="add( <?php echo e($id); ?> );" data-idclient="<?php echo e($id); ?>" id="delete" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i></button>
-->
