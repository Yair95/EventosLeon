<button class="btn btn-primary btn-sm"
  data-iduser="<?php echo e($id); ?>"
  data-nameuser="<?php echo e($name); ?>"
  data-emailuser="<?php echo e($email); ?>"
  data-toggle="modal" data-target="#edit"><i class="fa fa-edit"></i></button>

<a class="btn btn-danger btn-sm" onclick="add( <?php echo e($id); ?> );" data-id="<?php echo e($id); ?>">
  <i class="fa fa-trash"></i></a>
