<div class="form-group">
  <div class="form-group col-md-6">
    <label for="service_name">Nombre del servicio</label>
    <input type="text" class="form-control" name="service_name" id="service_name">
  </div>
  <div class="form-group col-md-6">
    <label for="description">Descripción</label>
    <input type="text" class="form-control" name="description" id="description">
  </div>
  <div class="form-group col-md-6">
    <label for="cost">Costo</label>
    <input type="number" class="form-control" name="cost" id="cost">
  </div>
</div>

<div class="form-group">
  <div class="form-group col-md-6">
    <label for="provider_id">Proveedor</label>
    <select class="form-control" name="provider_id" id="provider_id">
     <option value="1">Pancho</option>
     <option value="2">Emanuel</option>
     <option value="3">José</option>
     <option value="4">Fatima</option>
    </select>
  </div>
</div>
