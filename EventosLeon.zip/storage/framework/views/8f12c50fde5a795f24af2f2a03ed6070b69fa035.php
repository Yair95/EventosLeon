<?php $__env->startSection('content'); ?>

<section class="content-header">
  <h1>
    Proveedores
    <small>Agregar proveedor</small>
  </h1>
</section>

<form action="<?php echo e(url('provider')); ?>" method="post">
  <?php echo e(csrf_field()); ?>

<?php echo $__env->make('data_contact.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="form-group col-md-6">
<button type="submit" class="btn btn-primary">Guardar</button>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>