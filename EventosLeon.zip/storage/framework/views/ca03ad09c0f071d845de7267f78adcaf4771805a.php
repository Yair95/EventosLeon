<?php $__env->startSection('content-header'); ?>
  <h1>
    Servicios
    <small>Administración de Servicios</small>
  </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <h2>Lista de Servicios</h2>
        <a class="btn btn-success btn-md addNew" style="float: right;" href="<?php echo e(url('service/create')); ?>"><b>Agregar Nuevo</b></a><br><br>

      <div class="box-body">
          <table id="services_table" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Nombre</th>
                  <th>Descripción</th>
                  <th>Costo</th>
                  <th>Proveedor</th>
                  <th width="120px">Acciones</th>
              </tr>
          </thead>
      </table>
      </div>
<?php echo $__env->make('service.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
  <?php echo $__env->make('service.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>