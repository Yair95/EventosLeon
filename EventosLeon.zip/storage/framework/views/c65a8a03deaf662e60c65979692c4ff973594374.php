<?php $__env->startSection('adminlte_css'); ?>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
  <meta name="csrf-token" = content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
  <h1>
    Proveedores
    <small>Administración de Proveedores</small>
  </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <h2>Lista de Proveedores</h2>
          <a class="btn btn-success btn-md addNew" style="float: right;" href="<?php echo e(url('provider/create')); ?>"><b>Agregar Nuevo</b></a><br><br>

      <div class="box-body">
          <table id="provider_table" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  <th>Teléfono 1</th>
                  <th>Correo</th>
                  <th width="120px">Acciones</th>
              </tr>
          </thead>
      </table>
      </div>

      <?php echo $__env->make('provider.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <?php echo $__env->make('provider.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>