<?php $__env->startSection('content'); ?>
  <h1>Bienvenido</h1>
  <h3>Sistema de administración de eventos D'Leon</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>